import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Sidebar } from "./components/Sidebar";
import { ParticleCanvas } from "./components/ParticleCanvas";
import { SignalCard, Signal } from "./components/SignalCard";
import { MacroRiskGauge } from "./components/MacroRiskGauge";
import { BacktestResults } from "./components/BacktestResults";
import { PaperTrading } from "./components/PaperTrading";
import { AIVisionPanel } from "./components/AIVisionPanel";
import { TitaniumOrb } from "./components/TitaniumOrb";
import {
  Zap,
  TrendingUp,
  Shield,
  Activity,
  Clock,
  Wifi,
  RefreshCw,
  AlertTriangle,
} from "lucide-react";

const signals: Signal[] = [
  {
    asset: "BTC/USDT",
    price: 68432,
    change24h: 2.34,
    volume24h: "$38.2B",
    score: 9,
    maxScore: 11,
    direction: "LONG",
    strength: "STRONG",
    criteria: [
      { name: "EMA200 Alignment", pass: true, detail: "Price above" },
      { name: "Order Block", pass: true, detail: "67.1k–67.4k" },
      { name: "Fair Value Gap", pass: true, detail: "Open 68.0k" },
      { name: "Break of Structure", pass: true, detail: "4H confirmed" },
      { name: "ADX ≥ 25", pass: true, detail: "ADX: 31.4" },
      { name: "Liquidity Sweep", pass: true, detail: "Buy-side cleared" },
      { name: "Volume Confirm", pass: true, detail: "+220% avg" },
      { name: "RSI Zone", pass: true, detail: "58 — ok" },
      { name: "HTF Confluence", pass: true, detail: "Weekly bullish" },
      { name: "News Filter", pass: false, detail: "Risk: 34/100" },
      { name: "Funding Rate", pass: false, detail: "0.021% (high)" },
    ],
    tp1: 68500,
    tp2: 69200,
    tp3: 70500,
    sl: 66900,
    color: "#FFB300",
    lastUpdate: "2m ago",
  },
  {
    asset: "SOL/USDT",
    price: 178.23,
    change24h: 5.12,
    volume24h: "$4.7B",
    score: 8,
    maxScore: 11,
    direction: "LONG",
    strength: "STRONG",
    criteria: [
      { name: "EMA200 Alignment", pass: true, detail: "Price above" },
      { name: "Order Block", pass: true, detail: "170.0–172.5" },
      { name: "Fair Value Gap", pass: true, detail: "175.4–176.8" },
      { name: "Break of Structure", pass: true, detail: "1H confirmed" },
      { name: "ADX ≥ 25", pass: true, detail: "ADX: 28.7" },
      { name: "Liquidity Sweep", pass: true, detail: "Lows swept" },
      { name: "Volume Confirm", pass: true, detail: "+180% avg" },
      { name: "RSI Zone", pass: true, detail: "62 — ok" },
      { name: "HTF Confluence", pass: false, detail: "Daily neutral" },
      { name: "News Filter", pass: false, detail: "Risk: 34/100" },
      { name: "Funding Rate", pass: false, detail: "0.018% (ok)" },
    ],
    tp1: 182,
    tp2: 189,
    tp3: 198,
    sl: 168,
    color: "#9B59B6",
    lastUpdate: "4m ago",
  },
  {
    asset: "ETH/USDT",
    price: 3847,
    change24h: -0.71,
    volume24h: "$18.1B",
    score: 7,
    maxScore: 11,
    direction: "SHORT",
    strength: "MODERATE",
    criteria: [
      { name: "EMA200 Alignment", pass: false, detail: "Below EMA50" },
      { name: "Order Block", pass: true, detail: "3890–3920 bear" },
      { name: "Fair Value Gap", pass: true, detail: "Imbal 3760" },
      { name: "Break of Structure", pass: true, detail: "CHoCH 1H" },
      { name: "ADX ≥ 25", pass: true, detail: "ADX: 26.1" },
      { name: "Liquidity Sweep", pass: true, detail: "Highs swept" },
      { name: "Volume Confirm", pass: true, detail: "+140% avg" },
      { name: "RSI Zone", pass: true, detail: "44 — ok" },
      { name: "HTF Confluence", pass: false, detail: "4H mixed" },
      { name: "News Filter", pass: true, detail: "Risk: 34/100" },
      { name: "Funding Rate", pass: false, detail: "0.012% (ok)" },
    ],
    tp1: 3820,
    tp2: 3740,
    tp3: 3620,
    sl: 3960,
    color: "#00D4FF",
    lastUpdate: "7m ago",
  },
  {
    asset: "PAXG/USDT",
    price: 2345,
    change24h: 0.43,
    volume24h: "$142M",
    score: 5,
    maxScore: 11,
    direction: "NEUTRAL",
    strength: "WEAK",
    criteria: [
      { name: "EMA200 Alignment", pass: true, detail: "Above EMA200" },
      { name: "Order Block", pass: true, detail: "2310–2330" },
      { name: "Fair Value Gap", pass: false, detail: "None open" },
      { name: "Break of Structure", pass: false, detail: "Ranging" },
      { name: "ADX ≥ 25", pass: false, detail: "ADX: 18.2" },
      { name: "Liquidity Sweep", pass: false, detail: "Pending" },
      { name: "Volume Confirm", pass: false, detail: "+60% avg" },
      { name: "RSI Zone", pass: true, detail: "52 — ok" },
      { name: "HTF Confluence", pass: false, detail: "Weekly ranging" },
      { name: "News Filter", pass: true, detail: "Risk: 34/100" },
      { name: "Funding Rate", pass: true, detail: "0.003% (low)" },
    ],
    tp1: 2380,
    tp2: 2420,
    tp3: 2490,
    sl: 2290,
    color: "#00F5C4",
    lastUpdate: "12m ago",
  },
];

const moduleContent: Record<string, React.ReactNode> = {};

function StatPill({
  label,
  value,
  color,
  icon,
}: {
  label: string;
  value: string;
  color: string;
  icon: React.ReactNode;
}) {
  return (
    <div
      className="flex items-center gap-2 px-3 py-2"
      style={{
        background: `${color}0D`,
        border: `1px solid ${color}25`,
        borderRadius: 4,
      }}
    >
      <span style={{ color }}>{icon}</span>
      <div>
        <div style={{ color: "#5A7A9A", fontSize: 8, fontFamily: "'JetBrains Mono', monospace", letterSpacing: "0.12em" }}>
          {label}
        </div>
        <div style={{ color, fontFamily: "'JetBrains Mono', monospace", fontSize: 13, fontWeight: 700, lineHeight: 1.1 }}>
          {value}
        </div>
      </div>
    </div>
  );
}

function TopBar() {
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const t = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  return (
    <div
      className="flex items-center justify-between px-6 py-2.5"
      style={{
        background: "#070D1A",
        borderBottom: "1px solid rgba(0,212,255,0.08)",
        height: 48,
        flexShrink: 0,
      }}
    >
      <div className="flex items-center gap-6">
        <StatPill label="SIGNALS TODAY" value="4" color="#00D4FF" icon={<Zap size={11} />} />
        <StatPill label="WIN RATE" value="67.3%" color="#00F5C4" icon={<TrendingUp size={11} />} />
        <StatPill label="MACRO RISK" value="34/100" color="#FFB300" icon={<Shield size={11} />} />
        <StatPill label="OPEN TRADES" value="3" color="#9B59B6" icon={<Activity size={11} />} />
      </div>
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-1.5">
          <Wifi size={11} style={{ color: "#00F5C4" }} />
          <span style={{ color: "#5A7A9A", fontSize: 9, fontFamily: "'JetBrains Mono', monospace" }}>
            Binance WS · 23ms
          </span>
        </div>
        <div className="flex items-center gap-1.5">
          <Clock size={11} style={{ color: "#5A7A9A" }} />
          <span style={{ color: "#5A7A9A", fontSize: 9, fontFamily: "'JetBrains Mono', monospace" }}>
            {time.toUTCString().slice(17, 25)} UTC
          </span>
        </div>
        <div
          className="flex items-center gap-1"
          style={{
            color: "#00D4FF",
            fontSize: 9,
            fontFamily: "'JetBrains Mono', monospace",
            background: "rgba(0,212,255,0.08)",
            border: "1px solid rgba(0,212,255,0.15)",
            padding: "3px 8px",
            borderRadius: 3,
            cursor: "pointer",
          }}
        >
          <RefreshCw size={9} />
          <span>AUTO</span>
        </div>
      </div>
    </div>
  );
}

function DashboardView() {
  const [expandedCard, setExpandedCard] = useState<string | null>(null);

  return (
    <div className="flex flex-col gap-4 p-5 overflow-y-auto h-full">
      {/* Hero section */}
      <div
        className="relative flex items-center overflow-hidden"
        style={{
          background: "linear-gradient(135deg, #070D1A 0%, #0A1525 60%, #0D1A30 100%)",
          border: "1px solid rgba(0,212,255,0.12)",
          borderRadius: 8,
          padding: "24px 32px",
          minHeight: 160,
        }}
      >
        <ParticleCanvas />
        <div className="relative z-10 flex-1">
          <div
            style={{
              color: "#5A7A9A",
              fontSize: 10,
              fontFamily: "'JetBrains Mono', monospace",
              letterSpacing: "0.2em",
              marginBottom: 6,
            }}
          >
            ALGORITHMIC TRADING ENGINE · SMC v12
          </div>
          <h1
            style={{
              color: "#E2EAF4",
              fontFamily: "'Rajdhani', sans-serif",
              fontSize: 36,
              fontWeight: 700,
              letterSpacing: "0.04em",
              lineHeight: 1.1,
              marginBottom: 8,
            }}
          >
            TITANIUM{" "}
            <span
              style={{
                color: "#00D4FF",
                textShadow: "0 0 24px rgba(0,212,255,0.5)",
              }}
            >
              V12
            </span>
          </h1>
          <p
            style={{
              color: "#5A7A9A",
              fontSize: 13,
              fontFamily: "'Rajdhani', sans-serif",
              maxWidth: 480,
              lineHeight: 1.5,
            }}
          >
            Real-time Smart Money Concepts engine with 11-point signal scoring,
            walk-forward optimization, macro risk filtering, and local AI vision
            analysis via Ollama.
          </p>

          <div className="flex items-center gap-3 mt-4">
            {[
              { label: "BTC", price: "$68,432", change: "+2.34%", up: true, color: "#FFB300" },
              { label: "ETH", price: "$3,847", change: "-0.71%", up: false, color: "#00D4FF" },
              { label: "SOL", price: "$178.23", change: "+5.12%", up: true, color: "#9B59B6" },
              { label: "PAXG", price: "$2,345", change: "+0.43%", up: true, color: "#00F5C4" },
            ].map((a) => (
              <div
                key={a.label}
                className="px-3 py-2"
                style={{
                  background: "rgba(0,0,0,0.3)",
                  border: `1px solid ${a.color}25`,
                  borderRadius: 4,
                }}
              >
                <div
                  style={{
                    color: a.color,
                    fontSize: 9,
                    fontFamily: "'JetBrains Mono', monospace",
                    letterSpacing: "0.1em",
                    marginBottom: 2,
                  }}
                >
                  {a.label}
                </div>
                <div
                  style={{
                    color: "#E2EAF4",
                    fontFamily: "'JetBrains Mono', monospace",
                    fontSize: 13,
                    fontWeight: 600,
                  }}
                >
                  {a.price}
                </div>
                <div
                  style={{
                    color: a.up ? "#00F5C4" : "#FF3366",
                    fontSize: 9,
                    fontFamily: "'JetBrains Mono', monospace",
                  }}
                >
                  {a.change}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 3D Orb */}
        <div
          className="relative z-10 flex-shrink-0"
          style={{ marginLeft: 24, opacity: 0.9 }}
        >
          <TitaniumOrb />
          <div
            style={{
              position: "absolute",
              bottom: -10,
              left: "50%",
              transform: "translateX(-50%)",
              width: 80,
              height: 20,
              background: "radial-gradient(ellipse, rgba(0,212,255,0.15), transparent)",
              borderRadius: "50%",
            }}
          />
        </div>
      </div>

      {/* Signal cards */}
      <div>
        <div
          style={{
            color: "#5A7A9A",
            fontSize: 9,
            fontFamily: "'JetBrains Mono', monospace",
            letterSpacing: "0.2em",
            marginBottom: 10,
            paddingLeft: 2,
          }}
        >
          ACTIVE SIGNALS · {signals.filter((s) => s.score >= 7).length} TRADEABLE
        </div>
        <div className="grid grid-cols-4 gap-3">
          {signals.map((s) => (
            <SignalCard
              key={s.asset}
              signal={s}
              expanded={expandedCard === s.asset}
              onToggle={() =>
                setExpandedCard(expandedCard === s.asset ? null : s.asset)
              }
            />
          ))}
        </div>
      </div>

      {/* Middle row: Macro + Backtest */}
      <div className="grid grid-cols-2 gap-4">
        <MacroRiskGauge score={34} />
        <BacktestResults />
      </div>

      {/* Bottom row: Paper trading */}
      <PaperTrading />
    </div>
  );
}

function SignalsView() {
  const [expandedCard, setExpandedCard] = useState<string | null>(null);

  return (
    <div className="flex flex-col gap-4 p-5 overflow-y-auto h-full">
      <div>
        <h2
          style={{
            color: "#E2EAF4",
            fontFamily: "'Rajdhani', sans-serif",
            fontSize: 22,
            fontWeight: 700,
            letterSpacing: "0.06em",
            marginBottom: 4,
          }}
        >
          SMC SIGNAL MONITOR
        </h2>
        <p style={{ color: "#5A7A9A", fontSize: 12, fontFamily: "'JetBrains Mono', monospace" }}>
          11-point Smart Money Concepts scoring · Real-time Binance WebSocket
        </p>
      </div>

      {/* Signal log table header */}
      <div
        className="flex items-center gap-3 px-4 py-2"
        style={{
          background: "rgba(0,212,255,0.05)",
          border: "1px solid rgba(0,212,255,0.1)",
          borderRadius: 4,
        }}
      >
        {["ASSET", "PRICE", "SCORE", "DIRECTION", "STRENGTH", "LAST UPDATE"].map((h) => (
          <span
            key={h}
            style={{
              color: "#5A7A9A",
              fontSize: 8,
              fontFamily: "'JetBrains Mono', monospace",
              letterSpacing: "0.15em",
              flex: 1,
            }}
          >
            {h}
          </span>
        ))}
      </div>

      {signals.map((s, i) => (
        <motion.div
          key={s.asset}
          initial={{ opacity: 0, x: -10 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: i * 0.1 }}
          onClick={() =>
            setExpandedCard(expandedCard === s.asset ? null : s.asset)
          }
          className="cursor-pointer"
          style={{
            background: "linear-gradient(135deg, #0A1020, #0D1830)",
            border: `1px solid ${expandedCard === s.asset ? s.color + "30" : "rgba(0,212,255,0.08)"}`,
            borderRadius: 6,
            overflow: "hidden",
          }}
        >
          <div className="flex items-center gap-3 px-4 py-3">
            <span
              style={{
                flex: 1,
                color: s.color,
                fontFamily: "'JetBrains Mono', monospace",
                fontSize: 12,
                fontWeight: 700,
                letterSpacing: "0.06em",
              }}
            >
              {s.asset}
            </span>
            <span
              style={{
                flex: 1,
                color: "#E2EAF4",
                fontFamily: "'JetBrains Mono', monospace",
                fontSize: 12,
              }}
            >
              ${s.price.toLocaleString()}
            </span>
            <div style={{ flex: 1 }}>
              <div
                style={{
                  display: "inline-flex",
                  alignItems: "center",
                  gap: 6,
                  background: "rgba(0,0,0,0.3)",
                  padding: "2px 8px",
                  borderRadius: 3,
                }}
              >
                <div
                  style={{
                    height: 3,
                    width: 40,
                    background: "rgba(255,255,255,0.06)",
                    borderRadius: 2,
                    overflow: "hidden",
                  }}
                >
                  <div
                    style={{
                      height: "100%",
                      width: `${(s.score / s.maxScore) * 100}%`,
                      background: s.score >= 7 ? "#00F5C4" : s.score >= 5 ? "#FFB300" : "#FF3366",
                      borderRadius: 2,
                    }}
                  />
                </div>
                <span
                  style={{
                    color: "#E2EAF4",
                    fontFamily: "'JetBrains Mono', monospace",
                    fontSize: 11,
                    fontWeight: 600,
                  }}
                >
                  {s.score}/{s.maxScore}
                </span>
              </div>
            </div>
            <span
              style={{
                flex: 1,
                color: s.direction === "LONG" ? "#00F5C4" : s.direction === "SHORT" ? "#FF3366" : "#FFB300",
                fontFamily: "'JetBrains Mono', monospace",
                fontSize: 11,
                fontWeight: 700,
              }}
            >
              {s.direction}
            </span>
            <span
              style={{
                flex: 1,
                color: s.strength === "STRONG" ? "#00F5C4" : s.strength === "MODERATE" ? "#FFB300" : "#5A7A9A",
                fontFamily: "'JetBrains Mono', monospace",
                fontSize: 10,
              }}
            >
              {s.strength}
            </span>
            <span
              style={{
                flex: 1,
                color: "#5A7A9A",
                fontFamily: "'JetBrains Mono', monospace",
                fontSize: 10,
              }}
            >
              {s.lastUpdate}
            </span>
          </div>

          <AnimatePresence>
            {expandedCard === s.asset && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                style={{ borderTop: "1px solid rgba(0,212,255,0.08)", overflow: "hidden" }}
              >
                <div className="p-4">
                  <div className="grid grid-cols-11 gap-1.5 mb-3">
                    {s.criteria.map((c, ci) => (
                      <div
                        key={ci}
                        title={c.name}
                        style={{
                          background: c.pass ? "rgba(0,245,196,0.12)" : "rgba(255,51,102,0.08)",
                          border: `1px solid ${c.pass ? "rgba(0,245,196,0.2)" : "rgba(255,51,102,0.15)"}`,
                          borderRadius: 3,
                          padding: "6px 4px",
                          textAlign: "center",
                        }}
                      >
                        <div
                          style={{
                            width: 6,
                            height: 6,
                            borderRadius: "50%",
                            background: c.pass ? "#00F5C4" : "#FF3366",
                            margin: "0 auto 3px",
                            boxShadow: c.pass ? "0 0 4px rgba(0,245,196,0.6)" : "0 0 4px rgba(255,51,102,0.6)",
                          }}
                        />
                        <div
                          style={{
                            color: "#5A7A9A",
                            fontSize: 7,
                            fontFamily: "'JetBrains Mono', monospace",
                            lineHeight: 1.2,
                          }}
                        >
                          {c.name.split(" ")[0]}
                        </div>
                      </div>
                    ))}
                  </div>
                  <div className="grid grid-cols-4 gap-2">
                    {[
                      { l: "TP1 (33%)", v: s.tp1, c: "#00F5C4" },
                      { l: "TP2 (33%)", v: s.tp2, c: "#00D4FF" },
                      { l: "TP3 (34%)", v: s.tp3, c: "#B0C4D8" },
                      { l: "STOP LOSS", v: s.sl, c: "#FF3366" },
                    ].map((t) => (
                      <div
                        key={t.l}
                        className="text-center py-2"
                        style={{
                          background: "rgba(0,0,0,0.2)",
                          border: `1px solid ${t.c}20`,
                          borderRadius: 4,
                        }}
                      >
                        <div style={{ color: "#5A7A9A", fontSize: 8, fontFamily: "'JetBrains Mono', monospace", marginBottom: 3 }}>
                          {t.l}
                        </div>
                        <div style={{ color: t.c, fontFamily: "'JetBrains Mono', monospace", fontSize: 14, fontWeight: 700 }}>
                          ${t.v.toLocaleString()}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      ))}
    </div>
  );
}

function SignalLogView() {
  const logEntries = [
    { id: "SIG-042", asset: "BTC/USDT", dir: "LONG", score: 9, time: "14:32:07", status: "ACTIVE", pnl: "+$892" },
    { id: "SIG-041", asset: "SOL/USDT", dir: "LONG", score: 8, time: "10:14:52", status: "TP1 HIT", pnl: "+$251" },
    { id: "SIG-040", asset: "ETH/USDT", dir: "SHORT", score: 7, time: "09:47:11", status: "ACTIVE", pnl: "+$54" },
    { id: "SIG-039", asset: "BTC/USDT", dir: "LONG", score: 9, time: "Yesterday", status: "TP3 HIT", pnl: "+$1,240" },
    { id: "SIG-038", asset: "ETH/USDT", dir: "SHORT", score: 8, time: "Yesterday", status: "TP2 HIT", pnl: "+$340" },
    { id: "SIG-037", asset: "SOL/USDT", dir: "LONG", score: 6, time: "2d ago", status: "SL HIT", pnl: "-$87" },
    { id: "SIG-036", asset: "PAXG/USDT", dir: "LONG", score: 5, time: "2d ago", status: "SKIPPED", pnl: "—" },
    { id: "SIG-035", asset: "BTC/USDT", dir: "SHORT", score: 8, time: "3d ago", status: "TP1 HIT", pnl: "+$620" },
    { id: "SIG-034", asset: "ETH/USDT", dir: "LONG", score: 9, time: "3d ago", status: "TP3 HIT", pnl: "+$890" },
    { id: "SIG-033", asset: "SOL/USDT", dir: "SHORT", score: 7, time: "4d ago", status: "TP2 HIT", pnl: "+$410" },
  ];

  const statusColors: Record<string, string> = {
    ACTIVE: "#00D4FF",
    "TP1 HIT": "#00F5C4",
    "TP2 HIT": "#00F5C4",
    "TP3 HIT": "#00F5C4",
    "SL HIT": "#FF3366",
    SKIPPED: "#5A7A9A",
    CANCELLED: "#FFB300",
  };

  return (
    <div className="flex flex-col gap-4 p-5 overflow-y-auto h-full">
      <div>
        <h2
          style={{
            color: "#E2EAF4",
            fontFamily: "'Rajdhani', sans-serif",
            fontSize: 22,
            fontWeight: 700,
            letterSpacing: "0.06em",
            marginBottom: 4,
          }}
        >
          SIGNAL LOG
        </h2>
        <p style={{ color: "#5A7A9A", fontSize: 12, fontFamily: "'JetBrains Mono', monospace" }}>
          Full history of all generated signals
        </p>
      </div>

      <div
        style={{
          background: "linear-gradient(135deg, #0A1020, #0D1830)",
          border: "1px solid rgba(0,212,255,0.12)",
          borderRadius: 6,
          overflow: "hidden",
        }}
      >
        {/* Table header */}
        <div
          className="grid px-5 py-2.5"
          style={{
            gridTemplateColumns: "80px 120px 70px 60px 90px 110px 80px",
            background: "rgba(0,212,255,0.04)",
            borderBottom: "1px solid rgba(0,212,255,0.08)",
          }}
        >
          {["SIGNAL ID", "ASSET", "DIR", "SCORE", "TIME", "STATUS", "PnL"].map((h) => (
            <span
              key={h}
              style={{
                color: "#5A7A9A",
                fontSize: 8,
                fontFamily: "'JetBrains Mono', monospace",
                letterSpacing: "0.15em",
              }}
            >
              {h}
            </span>
          ))}
        </div>

        {logEntries.map((entry, i) => (
          <motion.div
            key={entry.id}
            initial={{ opacity: 0, x: -5 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.06 }}
            className="grid px-5 py-3 hover:bg-white/[0.02] transition-colors"
            style={{
              gridTemplateColumns: "80px 120px 70px 60px 90px 110px 80px",
              borderBottom: "1px solid rgba(0,212,255,0.04)",
            }}
          >
            <span style={{ color: "#5A7A9A", fontSize: 9, fontFamily: "'JetBrains Mono', monospace" }}>
              {entry.id}
            </span>
            <span style={{ color: "#E2EAF4", fontSize: 10, fontFamily: "'JetBrains Mono', monospace", fontWeight: 600 }}>
              {entry.asset}
            </span>
            <span
              style={{
                color: entry.dir === "LONG" ? "#00F5C4" : "#FF3366",
                fontSize: 10,
                fontFamily: "'JetBrains Mono', monospace",
                fontWeight: 700,
              }}
            >
              {entry.dir}
            </span>
            <span
              style={{
                color: entry.score >= 8 ? "#00F5C4" : entry.score >= 6 ? "#FFB300" : "#5A7A9A",
                fontSize: 10,
                fontFamily: "'JetBrains Mono', monospace",
                fontWeight: 700,
              }}
            >
              {entry.score}/11
            </span>
            <span style={{ color: "#5A7A9A", fontSize: 9, fontFamily: "'JetBrains Mono', monospace" }}>
              {entry.time}
            </span>
            <span
              style={{
                color: statusColors[entry.status] || "#5A7A9A",
                fontSize: 9,
                fontFamily: "'JetBrains Mono', monospace",
                background: (statusColors[entry.status] || "#5A7A9A") + "18",
                padding: "2px 7px",
                borderRadius: 2,
                display: "inline-block",
              }}
            >
              {entry.status}
            </span>
            <span
              style={{
                color: entry.pnl.startsWith("+") ? "#00F5C4" : entry.pnl.startsWith("-") ? "#FF3366" : "#5A7A9A",
                fontSize: 10,
                fontFamily: "'JetBrains Mono', monospace",
                fontWeight: entry.pnl !== "—" ? 700 : 400,
              }}
            >
              {entry.pnl}
            </span>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

const moduleMap: Record<string, React.ReactNode> = {
  dashboard: <DashboardView />,
  signals: <SignalsView />,
  backtest: (
    <div className="p-5 overflow-y-auto h-full">
      <div className="mb-4">
        <h2 style={{ color: "#E2EAF4", fontFamily: "'Rajdhani', sans-serif", fontSize: 22, fontWeight: 700, letterSpacing: "0.06em", marginBottom: 4 }}>
          WALK-FORWARD OPTIMIZER
        </h2>
        <p style={{ color: "#5A7A9A", fontSize: 12, fontFamily: "'JetBrains Mono', monospace" }}>
          In-sample / out-of-sample validation for SL/TP parameters
        </p>
      </div>
      <BacktestResults />
    </div>
  ),
  macro: (
    <div className="p-5 overflow-y-auto h-full">
      <div className="mb-4">
        <h2 style={{ color: "#E2EAF4", fontFamily: "'Rajdhani', sans-serif", fontSize: 22, fontWeight: 700, letterSpacing: "0.06em", marginBottom: 4 }}>
          MACRO RISK FILTER
        </h2>
        <p style={{ color: "#5A7A9A", fontSize: 12, fontFamily: "'JetBrains Mono', monospace" }}>
          Real-time news aggregation · Signals blocked above threshold 70/100
        </p>
      </div>
      <MacroRiskGauge score={34} />
    </div>
  ),
  paper: (
    <div className="p-5 overflow-y-auto h-full">
      <div className="mb-4">
        <h2 style={{ color: "#E2EAF4", fontFamily: "'Rajdhani', sans-serif", fontSize: 22, fontWeight: 700, letterSpacing: "0.06em", marginBottom: 4 }}>
          PAPER TRADING ENGINE
        </h2>
        <p style={{ color: "#5A7A9A", fontSize: 12, fontFamily: "'JetBrains Mono', monospace" }}>
          Simulated trades · Slippage & fees included · Partial exits TP1/2/3
        </p>
      </div>
      <PaperTrading />
    </div>
  ),
  vision: (
    <div className="p-5 overflow-y-auto h-full">
      <div className="mb-4">
        <h2 style={{ color: "#E2EAF4", fontFamily: "'Rajdhani', sans-serif", fontSize: 22, fontWeight: 700, letterSpacing: "0.06em", marginBottom: 4 }}>
          AI VISION ANALYSIS
        </h2>
        <p style={{ color: "#5A7A9A", fontSize: 12, fontFamily: "'JetBrains Mono', monospace" }}>
          Local chart analysis via Ollama · LLaVA & Qwen2.5-VL models
        </p>
      </div>
      <AIVisionPanel />
    </div>
  ),
  log: <SignalLogView />,
};

export default function App() {
  const [activeModule, setActiveModule] = useState("dashboard");

  return (
    <div
      className="flex h-full w-full overflow-hidden"
      style={{ background: "#050A14", fontFamily: "'Inter', sans-serif" }}
    >
      <Sidebar activeModule={activeModule} onModuleChange={setActiveModule} />
      <div className="flex flex-col flex-1 min-w-0 overflow-hidden">
        <TopBar />
        <div className="flex-1 overflow-hidden">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeModule}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.2 }}
              className="h-full"
              style={{ overflowY: "auto" }}
            >
              {moduleMap[activeModule] ?? <DashboardView />}
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
