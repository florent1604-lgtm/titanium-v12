import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  TrendingUp,
  TrendingDown,
  DollarSign,
  Activity,
  X,
  CheckCircle,
  Clock,
} from "lucide-react";
import {
  LineChart,
  Line,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
  CartesianGrid,
} from "recharts";

interface Trade {
  id: string;
  asset: string;
  direction: "LONG" | "SHORT";
  entry: number;
  current: number;
  tp1: number;
  tp2: number;
  tp3: number;
  sl: number;
  size: number;
  pnl: number;
  pnlPct: number;
  status: "OPEN" | "TP1" | "TP2" | "CLOSED";
  openedAt: string;
  color: string;
}

const activeTrades: Trade[] = [
  {
    id: "T-001",
    asset: "BTC/USDT",
    direction: "LONG",
    entry: 67840,
    current: 68432,
    tp1: 68500,
    tp2: 69200,
    tp3: 70500,
    sl: 66900,
    size: 0.15,
    pnl: +892.5,
    pnlPct: +2.34,
    status: "OPEN",
    openedAt: "2h 14m",
    color: "#FFB300",
  },
  {
    id: "T-002",
    asset: "SOL/USDT",
    direction: "LONG",
    entry: 169.4,
    current: 178.23,
    tp1: 174.0,
    tp2: 182.0,
    tp3: 195.0,
    sl: 162.0,
    size: 28.5,
    pnl: +251.6,
    pnlPct: +5.21,
    status: "TP1",
    openedAt: "4h 52m",
    color: "#9B59B6",
  },
  {
    id: "T-003",
    asset: "ETH/USDT",
    direction: "SHORT",
    entry: 3892,
    current: 3847,
    tp1: 3820,
    tp2: 3740,
    tp3: 3620,
    sl: 3960,
    size: 1.2,
    pnl: +54.0,
    pnlPct: +1.16,
    status: "OPEN",
    openedAt: "47m",
    color: "#00D4FF",
  },
];

const pnlHistory = [
  { day: "D-11", pnl: 0 },
  { day: "D-10", pnl: 420 },
  { day: "D-9", pnl: 1180 },
  { day: "D-8", pnl: 870 },
  { day: "D-7", pnl: 2340 },
  { day: "D-6", pnl: 3100 },
  { day: "D-5", pnl: 2780 },
  { day: "D-4", pnl: 4200 },
  { day: "D-3", pnl: 5800 },
  { day: "D-2", pnl: 7400 },
  { day: "D-1", pnl: 11200 },
  { day: "Today", pnl: 12847 },
];

const closedCount = 47;
const totalPnl = 12847;
const winRate = 67.3;
const avgRR = 2.14;

export function PaperTrading() {
  const [selected, setSelected] = useState<string | null>(null);

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (!active || !payload?.length) return null;
    return (
      <div
        style={{
          background: "#0D1526",
          border: "1px solid rgba(0,212,255,0.2)",
          borderRadius: 4,
          padding: "6px 10px",
          fontFamily: "'JetBrains Mono', monospace",
          fontSize: 10,
        }}
      >
        <div style={{ color: "#5A7A9A" }}>{label}</div>
        <div style={{ color: "#00F5C4" }}>${payload[0].value.toLocaleString()}</div>
      </div>
    );
  };

  return (
    <div
      style={{
        background: "linear-gradient(135deg, #0A1020, #0D1830)",
        border: "1px solid rgba(0,212,255,0.12)",
        borderRadius: 6,
        overflow: "hidden",
        fontFamily: "'Rajdhani', sans-serif",
      }}
    >
      {/* Header */}
      <div
        className="flex items-center justify-between px-5 py-3"
        style={{ borderBottom: "1px solid rgba(0,212,255,0.08)" }}
      >
        <div className="flex items-center gap-2">
          <Activity size={16} style={{ color: "#00D4FF" }} />
          <span style={{ color: "#E2EAF4", fontWeight: 600, fontSize: 14, letterSpacing: "0.06em" }}>
            PAPER TRADING ENGINE
          </span>
        </div>
        <div className="flex items-center gap-2">
          <span
            style={{
              color: "#00F5C4",
              fontFamily: "'JetBrains Mono', monospace",
              fontSize: 13,
              fontWeight: 700,
              textShadow: "0 0 12px rgba(0,245,196,0.5)",
            }}
          >
            +${totalPnl.toLocaleString()}
          </span>
          <span style={{ color: "#5A7A9A", fontSize: 10, fontFamily: "'JetBrains Mono', monospace" }}>
            total PnL
          </span>
        </div>
      </div>

      {/* Stats */}
      <div
        className="grid grid-cols-4"
        style={{ borderBottom: "1px solid rgba(0,212,255,0.08)" }}
      >
        {[
          { label: "OPEN", value: `${activeTrades.length}`, icon: <Clock size={11} />, color: "#00D4FF" },
          { label: "CLOSED", value: `${closedCount}`, icon: <CheckCircle size={11} />, color: "#00F5C4" },
          { label: "WIN RATE", value: `${winRate}%`, icon: <TrendingUp size={11} />, color: "#FFB300" },
          { label: "AVG R/R", value: `${avgRR}`, icon: <DollarSign size={11} />, color: "#9B59B6" },
        ].map((s, i) => (
          <div
            key={i}
            className="flex flex-col items-center justify-center py-3"
            style={{ borderRight: i < 3 ? "1px solid rgba(0,212,255,0.06)" : "none" }}
          >
            <div className="flex items-center gap-1 mb-1">
              <span style={{ color: s.color }}>{s.icon}</span>
              <span style={{ color: "#5A7A9A", fontSize: 8, fontFamily: "'JetBrains Mono', monospace", letterSpacing: "0.1em" }}>
                {s.label}
              </span>
            </div>
            <span
              style={{
                color: s.color,
                fontFamily: "'JetBrains Mono', monospace",
                fontSize: 20,
                fontWeight: 700,
              }}
            >
              {s.value}
            </span>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-2 gap-0">
        {/* Active trades */}
        <div
          className="p-4"
          style={{ borderRight: "1px solid rgba(0,212,255,0.08)" }}
        >
          <div
            style={{
              color: "#5A7A9A",
              fontSize: 9,
              fontFamily: "'JetBrains Mono', monospace",
              letterSpacing: "0.15em",
              marginBottom: 10,
            }}
          >
            ACTIVE POSITIONS
          </div>
          <div className="flex flex-col gap-2">
            {activeTrades.map((t) => {
              const isSelected = selected === t.id;
              const progress = Math.abs((t.current - t.entry) / (t.tp3 - t.entry)) * 100;
              return (
                <motion.div
                  key={t.id}
                  onClick={() => setSelected(isSelected ? null : t.id)}
                  whileHover={{ x: 2 }}
                  className="cursor-pointer"
                  style={{
                    background: isSelected ? "rgba(0,212,255,0.06)" : "rgba(0,0,0,0.2)",
                    border: `1px solid ${isSelected ? t.color + "40" : "rgba(0,212,255,0.08)"}`,
                    borderRadius: 4,
                    padding: "10px 12px",
                  }}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <span
                        style={{
                          color: t.color,
                          fontFamily: "'JetBrains Mono', monospace",
                          fontSize: 11,
                          fontWeight: 700,
                          letterSpacing: "0.06em",
                        }}
                      >
                        {t.asset}
                      </span>
                      <span
                        style={{
                          color: t.direction === "LONG" ? "#00F5C4" : "#FF3366",
                          fontSize: 8,
                          fontFamily: "'JetBrains Mono', monospace",
                          background: (t.direction === "LONG" ? "#00F5C4" : "#FF3366") + "18",
                          padding: "1px 5px",
                          borderRadius: 2,
                        }}
                      >
                        {t.direction}
                      </span>
                      {t.status !== "OPEN" && (
                        <span
                          style={{
                            color: "#FFB300",
                            fontSize: 8,
                            fontFamily: "'JetBrains Mono', monospace",
                            background: "rgba(255,179,0,0.15)",
                            padding: "1px 5px",
                            borderRadius: 2,
                          }}
                        >
                          {t.status} HIT
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-1">
                      {t.pnl > 0 ? (
                        <TrendingUp size={10} style={{ color: "#00F5C4" }} />
                      ) : (
                        <TrendingDown size={10} style={{ color: "#FF3366" }} />
                      )}
                      <span
                        style={{
                          color: t.pnl > 0 ? "#00F5C4" : "#FF3366",
                          fontFamily: "'JetBrains Mono', monospace",
                          fontSize: 12,
                          fontWeight: 700,
                        }}
                      >
                        {t.pnl > 0 ? "+" : ""}${t.pnl.toFixed(0)}
                      </span>
                    </div>
                  </div>

                  {/* Progress bar */}
                  <div
                    style={{
                      height: 3,
                      background: "rgba(255,255,255,0.05)",
                      borderRadius: 2,
                      overflow: "hidden",
                      marginBottom: 6,
                    }}
                  >
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: `${Math.min(progress, 100)}%` }}
                      transition={{ duration: 0.8 }}
                      style={{
                        height: "100%",
                        background: `linear-gradient(90deg, ${t.color}, ${t.color}80)`,
                        borderRadius: 2,
                      }}
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <span style={{ color: "#5A7A9A", fontSize: 8, fontFamily: "'JetBrains Mono', monospace" }}>
                      Entry: {t.entry.toLocaleString()}
                    </span>
                    <span
                      style={{
                        color: t.pnl > 0 ? "#00F5C4" : "#FF3366",
                        fontSize: 8,
                        fontFamily: "'JetBrains Mono', monospace",
                      }}
                    >
                      {t.pnlPct > 0 ? "+" : ""}{t.pnlPct.toFixed(2)}% · {t.openedAt}
                    </span>
                  </div>

                  {/* Expanded details */}
                  <AnimatePresence>
                    {isSelected && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: "auto" }}
                        exit={{ opacity: 0, height: 0 }}
                        style={{ marginTop: 8, paddingTop: 8, borderTop: "1px solid rgba(0,212,255,0.08)" }}
                      >
                        <div className="grid grid-cols-4 gap-1">
                          {[
                            { l: "TP1", v: t.tp1, c: "#00F5C4" },
                            { l: "TP2", v: t.tp2, c: "#00D4FF" },
                            { l: "TP3", v: t.tp3, c: "#B0C4D8" },
                            { l: "SL", v: t.sl, c: "#FF3366" },
                          ].map((x) => (
                            <div key={x.l} className="text-center">
                              <div style={{ color: "#5A7A9A", fontSize: 7, fontFamily: "'JetBrains Mono', monospace" }}>
                                {x.l}
                              </div>
                              <div style={{ color: x.c, fontSize: 9, fontFamily: "'JetBrains Mono', monospace", fontWeight: 600 }}>
                                {x.v.toLocaleString()}
                              </div>
                            </div>
                          ))}
                        </div>
                        <div
                          style={{
                            color: "#5A7A9A",
                            fontSize: 8,
                            fontFamily: "'JetBrains Mono', monospace",
                            marginTop: 6,
                          }}
                        >
                          Size: {t.size} · Exits: 33% / 33% / 34%
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* PnL Chart */}
        <div className="p-4">
          <div
            style={{
              color: "#5A7A9A",
              fontSize: 9,
              fontFamily: "'JetBrains Mono', monospace",
              letterSpacing: "0.15em",
              marginBottom: 10,
            }}
          >
            CUMULATIVE PnL (12 DAYS)
          </div>
          <ResponsiveContainer width="100%" height={140}>
            <LineChart data={pnlHistory} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="pnlGrad" x1="0" y1="0" x2="1" y2="0">
                  <stop offset="0%" stopColor="#00D4FF" />
                  <stop offset="100%" stopColor="#00F5C4" />
                </linearGradient>
              </defs>
              <CartesianGrid stroke="rgba(0,212,255,0.05)" strokeDasharray="3 3" />
              <XAxis
                dataKey="day"
                tick={{ fill: "#5A7A9A", fontSize: 8, fontFamily: "'JetBrains Mono', monospace" }}
                axisLine={false}
                tickLine={false}
                interval={2}
              />
              <YAxis
                tick={{ fill: "#5A7A9A", fontSize: 8, fontFamily: "'JetBrains Mono', monospace" }}
                axisLine={false}
                tickLine={false}
                tickFormatter={(v) => `$${(v / 1000).toFixed(0)}k`}
              />
              <Tooltip content={<CustomTooltip />} />
              <Line
                type="monotone"
                dataKey="pnl"
                stroke="url(#pnlGrad)"
                strokeWidth={2.5}
                dot={false}
                activeDot={{ r: 4, fill: "#00F5C4", stroke: "#050A14", strokeWidth: 2 }}
              />
            </LineChart>
          </ResponsiveContainer>

          {/* Trade log snippet */}
          <div
            className="mt-3 pt-3"
            style={{ borderTop: "1px solid rgba(0,212,255,0.06)" }}
          >
            <div
              style={{
                color: "#5A7A9A",
                fontSize: 9,
                fontFamily: "'JetBrains Mono', monospace",
                letterSpacing: "0.12em",
                marginBottom: 6,
              }}
            >
              RECENT CLOSED
            </div>
            {[
              { a: "BTC/USDT", dir: "LONG", r: "+$1,240", c: "#00F5C4", t: "Yesterday" },
              { a: "ETH/USDT", dir: "SHORT", r: "+$340", c: "#00F5C4", t: "Yesterday" },
              { a: "SOL/USDT", dir: "LONG", r: "-$87", c: "#FF3366", t: "2d ago" },
            ].map((t, i) => (
              <div
                key={i}
                className="flex items-center justify-between py-1.5"
                style={{ borderBottom: "1px solid rgba(0,212,255,0.04)" }}
              >
                <div className="flex items-center gap-2">
                  <span style={{ color: "#7A9AB8", fontSize: 9, fontFamily: "'JetBrains Mono', monospace" }}>
                    {t.a}
                  </span>
                  <span
                    style={{
                      color: t.dir === "LONG" ? "#00F5C4" : "#FF3366",
                      fontSize: 7,
                      fontFamily: "'JetBrains Mono', monospace",
                      background: (t.dir === "LONG" ? "#00F5C4" : "#FF3366") + "15",
                      padding: "1px 4px",
                      borderRadius: 2,
                    }}
                  >
                    {t.dir}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span style={{ color: t.c, fontSize: 10, fontFamily: "'JetBrains Mono', monospace", fontWeight: 600 }}>
                    {t.r}
                  </span>
                  <span style={{ color: "#5A7A9A", fontSize: 8, fontFamily: "'JetBrains Mono', monospace" }}>
                    {t.t}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
