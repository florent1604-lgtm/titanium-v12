import { motion } from "motion/react";
import {
  LayoutDashboard,
  TrendingUp,
  BarChart3,
  Globe2,
  Cpu,
  BookOpen,
  Settings,
  Zap,
  ChevronRight,
} from "lucide-react";

interface NavItem {
  id: string;
  label: string;
  icon: React.ReactNode;
  badge?: string;
}

interface SidebarProps {
  activeModule: string;
  onModuleChange: (id: string) => void;
}

const navItems: NavItem[] = [
  { id: "dashboard", label: "Dashboard", icon: <LayoutDashboard size={16} /> },
  { id: "signals", label: "SMC Signals", icon: <Zap size={16} />, badge: "4" },
  { id: "backtest", label: "Optimizer", icon: <BarChart3 size={16} /> },
  { id: "macro", label: "Macro Risk", icon: <Globe2 size={16} /> },
  { id: "paper", label: "Paper Trading", icon: <TrendingUp size={16} /> },
  { id: "vision", label: "AI Vision", icon: <Cpu size={16} /> },
  { id: "log", label: "Signal Log", icon: <BookOpen size={16} /> },
];

const assets = [
  { symbol: "BTC", change: +2.34, color: "#FFB300" },
  { symbol: "ETH", change: -0.71, color: "#00D4FF" },
  { symbol: "SOL", change: +5.12, color: "#9B59B6" },
  { symbol: "PAXG", change: +0.43, color: "#00F5C4" },
];

export function Sidebar({ activeModule, onModuleChange }: SidebarProps) {
  return (
    <div
      className="flex flex-col h-full"
      style={{
        background: "#070D1A",
        borderRight: "1px solid rgba(0,212,255,0.1)",
        width: 220,
        minWidth: 220,
        fontFamily: "'Rajdhani', sans-serif",
      }}
    >
      {/* Logo */}
      <div
        className="flex items-center gap-3 px-5 py-5"
        style={{ borderBottom: "1px solid rgba(0,212,255,0.08)" }}
      >
        <div
          style={{
            width: 32,
            height: 32,
            background: "linear-gradient(135deg, #00D4FF, #00F5C4)",
            borderRadius: 4,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            boxShadow: "0 0 16px rgba(0,212,255,0.5)",
          }}
        >
          <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
            <polygon points="9,1 17,14 1,14" fill="#050A14" />
            <polygon points="9,5 14,13 4,13" fill="#00D4FF" opacity="0.6" />
            <circle cx="9" cy="9" r="2" fill="#ffffff" />
          </svg>
        </div>
        <div>
          <div
            style={{
              color: "#E2EAF4",
              fontWeight: 700,
              fontSize: 16,
              letterSpacing: "0.08em",
              lineHeight: 1,
            }}
          >
            TITANIUM
          </div>
          <div
            style={{
              color: "#00D4FF",
              fontWeight: 400,
              fontSize: 10,
              letterSpacing: "0.2em",
              fontFamily: "'JetBrains Mono', monospace",
            }}
          >
            v12 · SMC ENGINE
          </div>
        </div>
      </div>

      {/* System Status */}
      <div className="px-4 py-3">
        <div
          className="flex items-center justify-between px-3 py-2"
          style={{
            background: "rgba(0,245,196,0.06)",
            border: "1px solid rgba(0,245,196,0.15)",
            borderRadius: 4,
          }}
        >
          <div className="flex items-center gap-2">
            <div
              style={{
                width: 6,
                height: 6,
                borderRadius: "50%",
                background: "#00F5C4",
                boxShadow: "0 0 6px #00F5C4",
                animation: "pulse 2s infinite",
              }}
            />
            <span
              style={{
                color: "#00F5C4",
                fontSize: 10,
                fontFamily: "'JetBrains Mono', monospace",
                letterSpacing: "0.1em",
              }}
            >
              LIVE
            </span>
          </div>
          <span
            style={{
              color: "#5A7A9A",
              fontSize: 9,
              fontFamily: "'JetBrains Mono', monospace",
            }}
          >
            Binance WS
          </span>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3 py-2">
        <div
          style={{
            color: "#5A7A9A",
            fontSize: 9,
            letterSpacing: "0.2em",
            fontFamily: "'JetBrains Mono', monospace",
            padding: "8px 8px 4px",
          }}
        >
          MODULES
        </div>
        {navItems.map((item) => {
          const isActive = activeModule === item.id;
          return (
            <motion.button
              key={item.id}
              onClick={() => onModuleChange(item.id)}
              whileHover={{ x: 2 }}
              className="w-full flex items-center justify-between px-3 py-2 mb-0.5 rounded cursor-pointer transition-all"
              style={{
                background: isActive
                  ? "linear-gradient(90deg, rgba(0,212,255,0.12), rgba(0,212,255,0.04))"
                  : "transparent",
                border: isActive
                  ? "1px solid rgba(0,212,255,0.2)"
                  : "1px solid transparent",
                color: isActive ? "#00D4FF" : "#7A9AB8",
              }}
            >
              <div className="flex items-center gap-2.5">
                <span style={{ opacity: isActive ? 1 : 0.6 }}>{item.icon}</span>
                <span
                  style={{
                    fontSize: 13,
                    fontWeight: isActive ? 600 : 400,
                    letterSpacing: "0.04em",
                  }}
                >
                  {item.label}
                </span>
              </div>
              <div className="flex items-center gap-1">
                {item.badge && (
                  <span
                    style={{
                      background: "#00D4FF",
                      color: "#050A14",
                      fontSize: 9,
                      fontWeight: 700,
                      padding: "1px 5px",
                      borderRadius: 2,
                      fontFamily: "'JetBrains Mono', monospace",
                    }}
                  >
                    {item.badge}
                  </span>
                )}
                {isActive && (
                  <ChevronRight size={12} style={{ color: "#00D4FF" }} />
                )}
              </div>
            </motion.button>
          );
        })}
      </nav>

      {/* Assets mini-board */}
      <div
        className="px-4 py-3"
        style={{ borderTop: "1px solid rgba(0,212,255,0.08)" }}
      >
        <div
          style={{
            color: "#5A7A9A",
            fontSize: 9,
            letterSpacing: "0.2em",
            fontFamily: "'JetBrains Mono', monospace",
            marginBottom: 8,
          }}
        >
          WATCHLIST
        </div>
        {assets.map((a) => (
          <div key={a.symbol} className="flex items-center justify-between py-1">
            <span
              style={{
                color: a.color,
                fontSize: 11,
                fontFamily: "'JetBrains Mono', monospace",
                fontWeight: 600,
                letterSpacing: "0.08em",
              }}
            >
              {a.symbol}
            </span>
            <span
              style={{
                color: a.change >= 0 ? "#00F5C4" : "#FF3366",
                fontSize: 10,
                fontFamily: "'JetBrains Mono', monospace",
              }}
            >
              {a.change >= 0 ? "+" : ""}
              {a.change.toFixed(2)}%
            </span>
          </div>
        ))}
      </div>

      {/* Settings */}
      <div
        className="px-4 py-4"
        style={{ borderTop: "1px solid rgba(0,212,255,0.08)" }}
      >
        <button
          className="flex items-center gap-2 w-full"
          style={{ color: "#5A7A9A", fontSize: 12 }}
        >
          <Settings size={14} />
          <span style={{ fontFamily: "'Rajdhani', sans-serif" }}>Settings</span>
        </button>
      </div>
    </div>
  );
}
