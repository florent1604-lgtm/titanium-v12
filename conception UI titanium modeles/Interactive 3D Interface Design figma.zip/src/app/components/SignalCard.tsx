import { useRef, useState } from "react";
import { motion } from "motion/react";
import { TrendingUp, TrendingDown, Minus, Zap, Target } from "lucide-react";

interface SMCCriteria {
  name: string;
  pass: boolean;
  detail: string;
}

export interface Signal {
  asset: string;
  price: number;
  change24h: number;
  volume24h: string;
  score: number;
  maxScore: number;
  direction: "LONG" | "SHORT" | "NEUTRAL";
  strength: "STRONG" | "MODERATE" | "WEAK";
  criteria: SMCCriteria[];
  tp1: number;
  tp2: number;
  tp3: number;
  sl: number;
  color: string;
  lastUpdate: string;
}

interface SignalCardProps {
  signal: Signal;
  expanded?: boolean;
  onToggle?: () => void;
}

const directionConfig = {
  LONG: { color: "#00F5C4", icon: <TrendingUp size={14} />, label: "LONG" },
  SHORT: { color: "#FF3366", icon: <TrendingDown size={14} />, label: "SHORT" },
  NEUTRAL: { color: "#FFB300", icon: <Minus size={14} />, label: "NEUTRAL" },
};

const strengthGlow = {
  STRONG: "0 0 24px rgba(0,245,196,0.25)",
  MODERATE: "0 0 16px rgba(0,212,255,0.15)",
  WEAK: "0 0 8px rgba(90,122,154,0.1)",
};

export function SignalCard({ signal, expanded, onToggle }: SignalCardProps) {
  const cardRef = useRef<HTMLDivElement>(null);
  const [tilt, setTilt] = useState({ x: 0, y: 0 });
  const [hovered, setHovered] = useState(false);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const card = cardRef.current;
    if (!card) return;
    const rect = card.getBoundingClientRect();
    const x = (e.clientY - rect.top - rect.height / 2) / (rect.height / 2);
    const y = -(e.clientX - rect.left - rect.width / 2) / (rect.width / 2);
    setTilt({ x: x * 6, y: y * 6 });
  };

  const handleMouseLeave = () => {
    setTilt({ x: 0, y: 0 });
    setHovered(false);
  };

  const dir = directionConfig[signal.direction];
  const scorePercent = (signal.score / signal.maxScore) * 100;

  return (
    <motion.div
      ref={cardRef}
      onMouseMove={handleMouseMove}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={handleMouseLeave}
      animate={{
        rotateX: tilt.x,
        rotateY: tilt.y,
        scale: hovered ? 1.02 : 1,
      }}
      transition={{ type: "spring", stiffness: 300, damping: 20 }}
      style={{
        perspective: 1000,
        transformStyle: "preserve-3d",
        cursor: "pointer",
        background: "linear-gradient(135deg, #0A1020 0%, #0D1830 100%)",
        border: `1px solid ${hovered ? signal.color + "40" : "rgba(0,212,255,0.12)"}`,
        borderRadius: 6,
        padding: 0,
        boxShadow: hovered ? strengthGlow[signal.strength] : "none",
        transition: "border-color 0.3s, box-shadow 0.3s",
        overflow: "hidden",
      }}
      onClick={onToggle}
    >
      {/* Top accent bar */}
      <div
        style={{
          height: 2,
          background: `linear-gradient(90deg, ${signal.color}, transparent)`,
        }}
      />

      <div className="p-4">
        {/* Header row */}
        <div className="flex items-start justify-between mb-3">
          <div>
            <div className="flex items-center gap-2">
              <span
                style={{
                  color: signal.color,
                  fontFamily: "'JetBrains Mono', monospace",
                  fontSize: 16,
                  fontWeight: 700,
                  letterSpacing: "0.06em",
                  textShadow: `0 0 12px ${signal.color}80`,
                }}
              >
                {signal.asset}
              </span>
              <span
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 3,
                  color: dir.color,
                  fontSize: 10,
                  fontFamily: "'JetBrains Mono', monospace",
                  fontWeight: 700,
                  background: dir.color + "18",
                  border: `1px solid ${dir.color}30`,
                  padding: "2px 6px",
                  borderRadius: 2,
                  letterSpacing: "0.1em",
                }}
              >
                {dir.icon}
                {dir.label}
              </span>
            </div>
            <div
              style={{
                color: "#E2EAF4",
                fontFamily: "'JetBrains Mono', monospace",
                fontSize: 22,
                fontWeight: 600,
                letterSpacing: "-0.02em",
                lineHeight: 1.2,
                marginTop: 4,
              }}
            >
              ${signal.price.toLocaleString()}
            </div>
            <div
              style={{
                color: signal.change24h >= 0 ? "#00F5C4" : "#FF3366",
                fontFamily: "'JetBrains Mono', monospace",
                fontSize: 11,
                marginTop: 2,
              }}
            >
              {signal.change24h >= 0 ? "▲" : "▼"}{" "}
              {Math.abs(signal.change24h).toFixed(2)}% (24h)
            </div>
          </div>

          {/* Score circle */}
          <div
            style={{
              position: "relative",
              width: 64,
              height: 64,
            }}
          >
            <svg width="64" height="64" viewBox="0 0 64 64">
              <circle
                cx="32"
                cy="32"
                r="26"
                fill="none"
                stroke="rgba(0,212,255,0.1)"
                strokeWidth="4"
              />
              <circle
                cx="32"
                cy="32"
                r="26"
                fill="none"
                stroke={scorePercent >= 70 ? "#00F5C4" : scorePercent >= 45 ? "#FFB300" : "#FF3366"}
                strokeWidth="4"
                strokeLinecap="round"
                strokeDasharray={`${(scorePercent / 100) * 163.36} 163.36`}
                transform="rotate(-90 32 32)"
                style={{ transition: "stroke-dasharray 1s ease" }}
              />
            </svg>
            <div
              style={{
                position: "absolute",
                inset: 0,
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <span
                style={{
                  color: "#E2EAF4",
                  fontFamily: "'JetBrains Mono', monospace",
                  fontSize: 16,
                  fontWeight: 700,
                  lineHeight: 1,
                }}
              >
                {signal.score}
              </span>
              <span
                style={{
                  color: "#5A7A9A",
                  fontFamily: "'JetBrains Mono', monospace",
                  fontSize: 8,
                }}
              >
                /{signal.maxScore}
              </span>
            </div>
          </div>
        </div>

        {/* Score bar */}
        <div className="mb-3">
          <div className="flex justify-between mb-1">
            <span
              style={{
                color: "#5A7A9A",
                fontSize: 9,
                fontFamily: "'JetBrains Mono', monospace",
                letterSpacing: "0.12em",
              }}
            >
              SMC SCORE
            </span>
            <span
              style={{
                color: "#5A7A9A",
                fontSize: 9,
                fontFamily: "'JetBrains Mono', monospace",
              }}
            >
              {signal.strength}
            </span>
          </div>
          <div
            style={{
              height: 3,
              background: "rgba(255,255,255,0.06)",
              borderRadius: 2,
              overflow: "hidden",
            }}
          >
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${scorePercent}%` }}
              transition={{ duration: 1, ease: "easeOut" }}
              style={{
                height: "100%",
                background:
                  scorePercent >= 70
                    ? "linear-gradient(90deg, #00D4FF, #00F5C4)"
                    : scorePercent >= 45
                    ? "linear-gradient(90deg, #FFB300, #FF6B35)"
                    : "linear-gradient(90deg, #FF3366, #FF6B35)",
                borderRadius: 2,
              }}
            />
          </div>
        </div>

        {/* TP/SL grid */}
        <div
          className="grid grid-cols-4 gap-1 mb-3"
          style={{
            background: "rgba(0,0,0,0.2)",
            border: "1px solid rgba(0,212,255,0.08)",
            borderRadius: 4,
            padding: "8px 10px",
          }}
        >
          {[
            { label: "TP1", value: signal.tp1, color: "#00F5C4" },
            { label: "TP2", value: signal.tp2, color: "#00D4FF" },
            { label: "TP3", value: signal.tp3, color: "#B0C4D8" },
            { label: "SL", value: signal.sl, color: "#FF3366" },
          ].map((t) => (
            <div key={t.label} className="text-center">
              <div
                style={{
                  color: "#5A7A9A",
                  fontSize: 8,
                  fontFamily: "'JetBrains Mono', monospace",
                  letterSpacing: "0.1em",
                }}
              >
                {t.label}
              </div>
              <div
                style={{
                  color: t.color,
                  fontSize: 10,
                  fontFamily: "'JetBrains Mono', monospace",
                  fontWeight: 600,
                }}
              >
                {t.value.toLocaleString()}
              </div>
            </div>
          ))}
        </div>

        {/* Expanded criteria */}
        {expanded && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
          >
            <div
              style={{
                color: "#5A7A9A",
                fontSize: 9,
                fontFamily: "'JetBrains Mono', monospace",
                letterSpacing: "0.15em",
                marginBottom: 6,
              }}
            >
              11-POINT SMC CRITERIA
            </div>
            <div className="grid grid-cols-1 gap-1">
              {signal.criteria.map((c, i) => (
                <div
                  key={i}
                  className="flex items-center justify-between px-2 py-1.5"
                  style={{
                    background: c.pass
                      ? "rgba(0,245,196,0.05)"
                      : "rgba(255,51,102,0.04)",
                    border: `1px solid ${c.pass ? "rgba(0,245,196,0.1)" : "rgba(255,51,102,0.08)"}`,
                    borderRadius: 3,
                  }}
                >
                  <div className="flex items-center gap-2">
                    <div
                      style={{
                        width: 5,
                        height: 5,
                        borderRadius: "50%",
                        background: c.pass ? "#00F5C4" : "#FF3366",
                        boxShadow: c.pass
                          ? "0 0 6px rgba(0,245,196,0.6)"
                          : "0 0 6px rgba(255,51,102,0.6)",
                      }}
                    />
                    <span
                      style={{
                        color: "#B0C4D8",
                        fontSize: 10,
                        fontFamily: "'Rajdhani', sans-serif",
                        fontWeight: 500,
                      }}
                    >
                      {c.name}
                    </span>
                  </div>
                  <span
                    style={{
                      color: "#5A7A9A",
                      fontSize: 9,
                      fontFamily: "'JetBrains Mono', monospace",
                    }}
                  >
                    {c.detail}
                  </span>
                </div>
              ))}
            </div>
          </motion.div>
        )}

        {/* Footer */}
        <div className="flex items-center justify-between mt-3 pt-2" style={{ borderTop: "1px solid rgba(0,212,255,0.06)" }}>
          <div className="flex items-center gap-1">
            <Zap size={10} style={{ color: "#00D4FF" }} />
            <span
              style={{
                color: "#5A7A9A",
                fontSize: 9,
                fontFamily: "'JetBrains Mono', monospace",
              }}
            >
              Vol: {signal.volume24h}
            </span>
          </div>
          <div className="flex items-center gap-1">
            <Target size={10} style={{ color: "#5A7A9A" }} />
            <span
              style={{
                color: "#5A7A9A",
                fontSize: 9,
                fontFamily: "'JetBrains Mono', monospace",
              }}
            >
              {signal.lastUpdate}
            </span>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
