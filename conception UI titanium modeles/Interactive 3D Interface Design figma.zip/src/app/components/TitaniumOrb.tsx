import { useEffect, useRef } from "react";
import { motion } from "motion/react";

export function TitaniumOrb() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const frameRef = useRef<number>(0);
  const tRef = useRef(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    canvas.width = 200;
    canvas.height = 200;

    const cx = 100;
    const cy = 100;
    const R = 70;
    const rings = 6;

    const drawFrame = () => {
      ctx.clearRect(0, 0, 200, 200);
      tRef.current += 0.012;
      const t = tRef.current;

      // Outer glow
      const grad = ctx.createRadialGradient(cx, cy, 10, cx, cy, R + 20);
      grad.addColorStop(0, "rgba(0,212,255,0.15)");
      grad.addColorStop(0.5, "rgba(0,212,255,0.05)");
      grad.addColorStop(1, "rgba(0,212,255,0)");
      ctx.beginPath();
      ctx.arc(cx, cy, R + 20, 0, Math.PI * 2);
      ctx.fillStyle = grad;
      ctx.fill();

      // Draw latitude rings
      for (let i = 1; i <= rings; i++) {
        const phi = (i / (rings + 1)) * Math.PI;
        const r2d = R * Math.sin(phi);
        const y = cy + R * Math.cos(phi);
        const a = t + i * 0.3;

        ctx.beginPath();
        ctx.ellipse(cx, y, r2d, r2d * Math.abs(Math.sin(a)) * 0.35 + 1, 0, 0, Math.PI * 2);
        const alpha = 0.15 + 0.3 * (i / rings);
        ctx.strokeStyle = `rgba(0,212,255,${alpha})`;
        ctx.lineWidth = 1;
        ctx.stroke();
      }

      // Draw longitude lines
      for (let j = 0; j < 8; j++) {
        const angle = (j / 8) * Math.PI + t * 0.5;
        const cosA = Math.cos(angle);

        ctx.beginPath();
        for (let k = 0; k <= 60; k++) {
          const phi = (k / 60) * Math.PI;
          const x3d = R * Math.sin(phi) * cosA;
          const y3d = -R * Math.cos(phi);
          const z3d = R * Math.sin(phi) * Math.sin(angle);
          const scale = 1 + z3d / (R * 4);
          const sx = cx + x3d * scale;
          const sy = cy + y3d * scale;
          if (k === 0) ctx.moveTo(sx, sy);
          else ctx.lineTo(sx, sy);
        }
        const vis = 0.05 + 0.25 * Math.max(0, Math.sin(angle));
        ctx.strokeStyle = `rgba(0,245,196,${vis})`;
        ctx.lineWidth = 0.8;
        ctx.stroke();
      }

      // Core sphere gradient
      const sphereGrad = ctx.createRadialGradient(cx - 18, cy - 18, 5, cx, cy, R);
      sphereGrad.addColorStop(0, "rgba(0,212,255,0.25)");
      sphereGrad.addColorStop(0.4, "rgba(0,100,180,0.12)");
      sphereGrad.addColorStop(1, "rgba(0,10,30,0.0)");
      ctx.beginPath();
      ctx.arc(cx, cy, R, 0, Math.PI * 2);
      ctx.fillStyle = sphereGrad;
      ctx.fill();

      // Specular highlight
      ctx.beginPath();
      ctx.ellipse(cx - 20, cy - 22, 18, 10, -Math.PI / 5, 0, Math.PI * 2);
      ctx.fillStyle = "rgba(255,255,255,0.08)";
      ctx.fill();

      // Orbiting particle
      const ox = cx + (R + 12) * Math.cos(t * 2);
      const oy = cy + (R + 12) * 0.3 * Math.sin(t * 2);
      ctx.beginPath();
      ctx.arc(ox, oy, 3, 0, Math.PI * 2);
      ctx.fillStyle = "#00F5C4";
      ctx.shadowBlur = 10;
      ctx.shadowColor = "#00F5C4";
      ctx.fill();
      ctx.shadowBlur = 0;

      const ox2 = cx + (R + 8) * Math.cos(t * 1.5 + Math.PI);
      const oy2 = cy + (R + 8) * 0.4 * Math.sin(t * 1.5 + Math.PI);
      ctx.beginPath();
      ctx.arc(ox2, oy2, 2, 0, Math.PI * 2);
      ctx.fillStyle = "#FFB300";
      ctx.shadowBlur = 8;
      ctx.shadowColor = "#FFB300";
      ctx.fill();
      ctx.shadowBlur = 0;

      frameRef.current = requestAnimationFrame(drawFrame);
    };

    drawFrame();
    return () => cancelAnimationFrame(frameRef.current);
  }, []);

  return (
    <motion.div
      animate={{ rotate: [0, 360] }}
      transition={{ duration: 60, repeat: Infinity, ease: "linear" }}
      style={{ width: 200, height: 200 }}
    >
      <canvas ref={canvasRef} style={{ width: 200, height: 200 }} />
    </motion.div>
  );
}
