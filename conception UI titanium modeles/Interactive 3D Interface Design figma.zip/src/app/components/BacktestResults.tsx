import { useState } from "react";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine,
  BarChart,
  Bar,
} from "recharts";
import { motion } from "motion/react";
import { BarChart3, TrendingUp, Award, Percent } from "lucide-react";

const equityCurve = [
  { period: "W1", inSample: 10000, outSample: 10000 },
  { period: "W2", inSample: 10420, outSample: 10350 },
  { period: "W3", inSample: 10890, outSample: 10700 },
  { period: "W4", inSample: 11340, outSample: 11050 },
  { period: "W5", inSample: 11120, outSample: 10900 },
  { period: "W6", inSample: 11780, outSample: 11430 },
  { period: "W7", inSample: 12340, outSample: 11980 },
  { period: "W8", inSample: 12780, outSample: 12300 },
  { period: "W9", inSample: 13100, outSample: 12650 },
  { period: "W10", inSample: 12700, outSample: 12200 },
  { period: "W11", inSample: 13450, outSample: 12900 },
  { period: "W12", inSample: 14200, outSample: 13580 },
];

const tradeDistribution = [
  { range: "-5%+", count: 2, fill: "#FF3366" },
  { range: "-3%", count: 5, fill: "#FF6B35" },
  { range: "-1%", count: 8, fill: "#FFB300" },
  { range: "+1%", count: 14, fill: "#00D4FF" },
  { range: "+3%", count: 18, fill: "#00F5C4" },
  { range: "+5%+", count: 9, fill: "#00F5C4" },
];

const params = [
  { label: "SL Multiplier", value: "1.8x ATR", optimal: true },
  { label: "TP1 (33%)", value: "1.2x SL", optimal: true },
  { label: "TP2 (33%)", value: "2.4x SL", optimal: true },
  { label: "TP3 (34%)", value: "4.0x SL", optimal: false },
  { label: "Min SMC Score", value: "7 / 11", optimal: true },
  { label: "ADX Threshold", value: "≥ 25", optimal: true },
];

const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div
      style={{
        background: "#0D1526",
        border: "1px solid rgba(0,212,255,0.2)",
        borderRadius: 4,
        padding: "8px 12px",
        fontFamily: "'JetBrains Mono', monospace",
        fontSize: 11,
      }}
    >
      <div style={{ color: "#5A7A9A", marginBottom: 4 }}>{label}</div>
      {payload.map((p: any) => (
        <div key={p.name} style={{ color: p.color }}>
          {p.name}: ${p.value.toLocaleString()}
        </div>
      ))}
    </div>
  );
};

export function BacktestResults() {
  const [activeTab, setActiveTab] = useState<"equity" | "distribution">("equity");

  const stats = [
    { label: "IS Sharpe", value: "2.41", color: "#00F5C4", icon: <Award size={12} /> },
    { label: "OOS Sharpe", value: "1.87", color: "#00D4FF", icon: <TrendingUp size={12} /> },
    { label: "Win Rate", value: "67.3%", color: "#FFB300", icon: <Percent size={12} /> },
    { label: "Max DD", value: "-8.2%", color: "#FF3366", icon: <BarChart3 size={12} /> },
  ];

  return (
    <div
      style={{
        background: "linear-gradient(135deg, #0A1020, #0D1830)",
        border: "1px solid rgba(0,212,255,0.12)",
        borderRadius: 6,
        overflow: "hidden",
        fontFamily: "'Rajdhani', sans-serif",
      }}
    >
      {/* Header */}
      <div
        className="flex items-center justify-between px-5 py-3"
        style={{ borderBottom: "1px solid rgba(0,212,255,0.08)" }}
      >
        <div className="flex items-center gap-2">
          <BarChart3 size={16} style={{ color: "#00D4FF" }} />
          <span style={{ color: "#E2EAF4", fontWeight: 600, fontSize: 14, letterSpacing: "0.06em" }}>
            WALK-FORWARD OPTIMIZER
          </span>
        </div>
        <div className="flex gap-1">
          {(["equity", "distribution"] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              style={{
                background: activeTab === tab ? "rgba(0,212,255,0.12)" : "transparent",
                border: `1px solid ${activeTab === tab ? "rgba(0,212,255,0.25)" : "rgba(0,212,255,0.08)"}`,
                color: activeTab === tab ? "#00D4FF" : "#5A7A9A",
                fontSize: 9,
                fontFamily: "'JetBrains Mono', monospace",
                letterSpacing: "0.1em",
                padding: "3px 8px",
                borderRadius: 3,
                cursor: "pointer",
              }}
            >
              {tab.toUpperCase()}
            </button>
          ))}
        </div>
      </div>

      {/* Stats row */}
      <div
        className="grid grid-cols-4 gap-0"
        style={{ borderBottom: "1px solid rgba(0,212,255,0.08)" }}
      >
        {stats.map((s, i) => (
          <div
            key={i}
            className="flex flex-col items-center justify-center py-3"
            style={{
              borderRight: i < 3 ? "1px solid rgba(0,212,255,0.06)" : "none",
            }}
          >
            <div className="flex items-center gap-1 mb-1">
              <span style={{ color: s.color }}>{s.icon}</span>
              <span style={{ color: "#5A7A9A", fontSize: 9, fontFamily: "'JetBrains Mono', monospace", letterSpacing: "0.1em" }}>
                {s.label}
              </span>
            </div>
            <span
              style={{
                color: s.color,
                fontFamily: "'JetBrains Mono', monospace",
                fontSize: 18,
                fontWeight: 700,
                textShadow: `0 0 12px ${s.color}60`,
              }}
            >
              {s.value}
            </span>
          </div>
        ))}
      </div>

      {/* Chart area */}
      <div className="p-4">
        {activeTab === "equity" ? (
          <div>
            <div className="flex items-center gap-4 mb-3">
              <div className="flex items-center gap-1.5">
                <div style={{ width: 12, height: 2, background: "#00F5C4" }} />
                <span style={{ color: "#5A7A9A", fontSize: 9, fontFamily: "'JetBrains Mono', monospace" }}>IN-SAMPLE</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div style={{ width: 12, height: 2, background: "#00D4FF", borderTop: "1px dashed #00D4FF" }} />
                <span style={{ color: "#5A7A9A", fontSize: 9, fontFamily: "'JetBrains Mono', monospace" }}>OUT-OF-SAMPLE</span>
              </div>
            </div>
            <ResponsiveContainer width="100%" height={180}>
              <AreaChart data={equityCurve} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="gradIS" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#00F5C4" stopOpacity={0.15} />
                    <stop offset="95%" stopColor="#00F5C4" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="gradOOS" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#00D4FF" stopOpacity={0.12} />
                    <stop offset="95%" stopColor="#00D4FF" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid stroke="rgba(0,212,255,0.05)" strokeDasharray="3 3" />
                <XAxis
                  dataKey="period"
                  tick={{ fill: "#5A7A9A", fontSize: 9, fontFamily: "'JetBrains Mono', monospace" }}
                  axisLine={false}
                  tickLine={false}
                />
                <YAxis
                  tick={{ fill: "#5A7A9A", fontSize: 9, fontFamily: "'JetBrains Mono', monospace" }}
                  axisLine={false}
                  tickLine={false}
                  tickFormatter={(v) => `$${(v / 1000).toFixed(0)}k`}
                />
                <Tooltip content={<CustomTooltip />} />
                <ReferenceLine y={10000} stroke="rgba(255,255,255,0.1)" strokeDasharray="4 4" />
                <Area
                  type="monotone"
                  dataKey="inSample"
                  name="In-Sample"
                  stroke="#00F5C4"
                  strokeWidth={2}
                  fill="url(#gradIS)"
                  dot={false}
                />
                <Area
                  type="monotone"
                  dataKey="outSample"
                  name="Out-of-Sample"
                  stroke="#00D4FF"
                  strokeWidth={2}
                  strokeDasharray="4 2"
                  fill="url(#gradOOS)"
                  dot={false}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        ) : (
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={tradeDistribution} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
              <CartesianGrid stroke="rgba(0,212,255,0.05)" strokeDasharray="3 3" vertical={false} />
              <XAxis
                dataKey="range"
                tick={{ fill: "#5A7A9A", fontSize: 9, fontFamily: "'JetBrains Mono', monospace" }}
                axisLine={false}
                tickLine={false}
              />
              <YAxis
                tick={{ fill: "#5A7A9A", fontSize: 9, fontFamily: "'JetBrains Mono', monospace" }}
                axisLine={false}
                tickLine={false}
              />
              <Bar dataKey="count" radius={[2, 2, 0, 0]}>
                {tradeDistribution.map((entry, index) => (
                  <rect key={index} fill={entry.fill} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        )}

        {/* Optimal params */}
        <div
          className="mt-3 pt-3"
          style={{ borderTop: "1px solid rgba(0,212,255,0.06)" }}
        >
          <div
            style={{
              color: "#5A7A9A",
              fontSize: 9,
              fontFamily: "'JetBrains Mono', monospace",
              letterSpacing: "0.15em",
              marginBottom: 8,
            }}
          >
            OPTIMAL PARAMETERS
          </div>
          <div className="grid grid-cols-3 gap-2">
            {params.map((p, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 4 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.08 }}
                className="px-2 py-1.5"
                style={{
                  background: "rgba(0,0,0,0.2)",
                  border: `1px solid ${p.optimal ? "rgba(0,245,196,0.12)" : "rgba(255,179,0,0.12)"}`,
                  borderRadius: 3,
                }}
              >
                <div
                  style={{
                    color: "#5A7A9A",
                    fontSize: 8,
                    fontFamily: "'JetBrains Mono', monospace",
                    marginBottom: 2,
                  }}
                >
                  {p.label}
                </div>
                <div
                  style={{
                    color: p.optimal ? "#00F5C4" : "#FFB300",
                    fontSize: 11,
                    fontFamily: "'JetBrains Mono', monospace",
                    fontWeight: 600,
                  }}
                >
                  {p.value}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
