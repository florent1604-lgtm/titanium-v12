import { useEffect, useRef } from "react";

interface Particle {
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  size: number;
  opacity: number;
  color: string;
}

export function ParticleCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animRef = useRef<number>(0);
  const particlesRef = useRef<Particle[]>([]);
  const mouseRef = useRef({ x: 0, y: 0 });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const resize = () => {
      canvas.width = canvas.offsetWidth;
      canvas.height = canvas.offsetHeight;
    };
    resize();
    window.addEventListener("resize", resize);

    const colors = ["#00D4FF", "#00F5C4", "#FFB300", "#B0C4D8"];
    const count = 80;

    particlesRef.current = Array.from({ length: count }, () => ({
      x: Math.random() * canvas.width,
      y: Math.random() * canvas.height,
      z: Math.random() * 600 + 100,
      vx: (Math.random() - 0.5) * 0.3,
      vy: (Math.random() - 0.5) * 0.3,
      vz: (Math.random() - 0.5) * 0.5,
      size: Math.random() * 2 + 0.5,
      opacity: Math.random() * 0.6 + 0.2,
      color: colors[Math.floor(Math.random() * colors.length)],
    }));

    const fov = 600;

    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      const mx = mouseRef.current.x;
      const my = mouseRef.current.y;

      const sorted = [...particlesRef.current].sort((a, b) => b.z - a.z);

      for (const p of sorted) {
        p.x += p.vx + (mx - canvas.width / 2) * 0.00008;
        p.y += p.vy + (my - canvas.height / 2) * 0.00008;
        p.z += p.vz;

        if (p.x < 0) p.x = canvas.width;
        if (p.x > canvas.width) p.x = 0;
        if (p.y < 0) p.y = canvas.height;
        if (p.y > canvas.height) p.y = 0;
        if (p.z < 50) p.z = 800;
        if (p.z > 800) p.z = 50;

        const scale = fov / (fov + p.z);
        const px = (p.x - canvas.width / 2) * scale + canvas.width / 2;
        const py = (p.y - canvas.height / 2) * scale + canvas.height / 2;
        const size = p.size * scale;
        const alpha = p.opacity * scale;

        ctx.beginPath();
        ctx.arc(px, py, size, 0, Math.PI * 2);
        ctx.fillStyle =
          p.color +
          Math.floor(Math.min(alpha * 255, 255))
            .toString(16)
            .padStart(2, "0");
        ctx.fill();

        // Draw connections
        for (const other of sorted) {
          if (other === p) continue;
          const os = fov / (fov + other.z);
          const ox = (other.x - canvas.width / 2) * os + canvas.width / 2;
          const oy = (other.y - canvas.height / 2) * os + canvas.height / 2;
          const dist = Math.hypot(px - ox, py - oy);
          if (dist < 80) {
            ctx.beginPath();
            ctx.moveTo(px, py);
            ctx.lineTo(ox, oy);
            ctx.strokeStyle = `rgba(0, 212, 255, ${(1 - dist / 80) * 0.08})`;
            ctx.lineWidth = 0.5;
            ctx.stroke();
          }
        }
      }

      animRef.current = requestAnimationFrame(draw);
    };

    const onMouseMove = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      mouseRef.current = {
        x: e.clientX - rect.left,
        y: e.clientY - rect.top,
      };
    };

    canvas.addEventListener("mousemove", onMouseMove);
    draw();

    return () => {
      cancelAnimationFrame(animRef.current);
      window.removeEventListener("resize", resize);
      canvas.removeEventListener("mousemove", onMouseMove);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 w-full h-full pointer-events-none"
      style={{ opacity: 0.6 }}
    />
  );
}
