import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Globe2, AlertTriangle, CheckCircle, Newspaper } from "lucide-react";

interface NewsItem {
  source: string;
  headline: string;
  impact: "high" | "medium" | "low";
  time: string;
}

interface MacroRiskGaugeProps {
  score: number;
}

const newsItems: NewsItem[] = [
  { source: "Reuters", headline: "Fed holds rates steady, signals dovish pivot in Q3", impact: "high", time: "14m ago" },
  { source: "GDELT", headline: "Geopolitical tension index drops to 6-month low", impact: "medium", time: "32m ago" },
  { source: "CoinDesk", headline: "Bitcoin ETF inflows surge $840M week-to-date", impact: "high", time: "1h ago" },
  { source: "Bloomberg", headline: "CPI report inline with estimates, volatility subdued", impact: "medium", time: "2h ago" },
  { source: "RSS", headline: "SEC crypto guidance update expected next week", impact: "low", time: "3h ago" },
];

const impactColors = {
  high: "#FF3366",
  medium: "#FFB300",
  low: "#00D4FF",
};

function GaugeArc({ score }: { score: number }) {
  const radius = 70;
  const cx = 100;
  const cy = 90;
  const startAngle = -Math.PI * 0.85;
  const endAngle = Math.PI * 0.85;
  const totalArc = endAngle - startAngle;

  const arcPath = (from: number, to: number) => {
    const x1 = cx + radius * Math.cos(from);
    const y1 = cy + radius * Math.sin(from);
    const x2 = cx + radius * Math.cos(to);
    const y2 = cy + radius * Math.sin(to);
    const large = to - from > Math.PI ? 1 : 0;
    return `M ${x1} ${y1} A ${radius} ${radius} 0 ${large} 1 ${x2} ${y2}`;
  };

  const scoreAngle = startAngle + (score / 100) * totalArc;
  const needleX = cx + (radius - 10) * Math.cos(scoreAngle);
  const needleY = cy + (radius - 10) * Math.sin(scoreAngle);

  const getColor = (s: number) =>
    s < 35 ? "#00F5C4" : s < 70 ? "#FFB300" : "#FF3366";

  const zones = [
    { from: startAngle, to: startAngle + totalArc * 0.35, color: "rgba(0,245,196,0.6)" },
    { from: startAngle + totalArc * 0.35, to: startAngle + totalArc * 0.7, color: "rgba(255,179,0,0.6)" },
    { from: startAngle + totalArc * 0.7, to: endAngle, color: "rgba(255,51,102,0.6)" },
  ];

  return (
    <svg width="200" height="120" viewBox="0 0 200 120">
      {/* Background zones */}
      {zones.map((z, i) => (
        <path
          key={i}
          d={arcPath(z.from, z.to)}
          fill="none"
          stroke={z.color}
          strokeWidth="8"
          strokeLinecap="butt"
          opacity="0.3"
        />
      ))}
      {/* Track */}
      <path
        d={arcPath(startAngle, endAngle)}
        fill="none"
        stroke="rgba(255,255,255,0.04)"
        strokeWidth="12"
      />
      {/* Score fill */}
      <motion.path
        d={arcPath(startAngle, scoreAngle)}
        fill="none"
        stroke={getColor(score)}
        strokeWidth="8"
        strokeLinecap="round"
        initial={{ pathLength: 0 }}
        animate={{ pathLength: 1 }}
        transition={{ duration: 1.5, ease: "easeOut" }}
        style={{ filter: `drop-shadow(0 0 6px ${getColor(score)})` }}
      />
      {/* Tick marks */}
      {[0, 25, 50, 75, 100].map((t) => {
        const a = startAngle + (t / 100) * totalArc;
        const ix = cx + (radius - 16) * Math.cos(a);
        const iy = cy + (radius - 16) * Math.sin(a);
        const ox = cx + (radius - 8) * Math.cos(a);
        const oy = cy + (radius - 8) * Math.sin(a);
        return (
          <line
            key={t}
            x1={ix}
            y1={iy}
            x2={ox}
            y2={oy}
            stroke="rgba(255,255,255,0.15)"
            strokeWidth="1.5"
          />
        );
      })}
      {/* Needle */}
      <motion.line
        x1={cx}
        y1={cy}
        x2={needleX}
        y2={needleY}
        stroke={getColor(score)}
        strokeWidth="2"
        strokeLinecap="round"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1, duration: 0.3 }}
      />
      <circle cx={cx} cy={cy} r="4" fill={getColor(score)} opacity="0.8" />
      {/* Center score */}
      <text
        x={cx}
        y={cy + 22}
        textAnchor="middle"
        fill={getColor(score)}
        fontSize="28"
        fontFamily="'JetBrains Mono', monospace"
        fontWeight="700"
      >
        {score}
      </text>
      <text
        x={cx}
        y={cy + 34}
        textAnchor="middle"
        fill="#5A7A9A"
        fontSize="8"
        fontFamily="'JetBrains Mono', monospace"
      >
        RISK INDEX
      </text>
      {/* Labels */}
      <text x="18" y="108" fill="#00F5C4" fontSize="8" fontFamily="'JetBrains Mono', monospace">LOW</text>
      <text x="83" y="22" fill="#FFB300" fontSize="8" fontFamily="'JetBrains Mono', monospace" textAnchor="middle">MED</text>
      <text x="168" y="108" fill="#FF3366" fontSize="8" fontFamily="'JetBrains Mono', monospace" textAnchor="end">HIGH</text>
    </svg>
  );
}

export function MacroRiskGauge({ score }: MacroRiskGaugeProps) {
  const [activeNews, setActiveNews] = useState(0);

  useEffect(() => {
    const t = setInterval(() => setActiveNews((n) => (n + 1) % newsItems.length), 4000);
    return () => clearInterval(t);
  }, []);

  const status =
    score < 35
      ? { label: "LOW RISK", color: "#00F5C4", icon: <CheckCircle size={14} /> }
      : score < 70
      ? { label: "CAUTION", color: "#FFB300", icon: <AlertTriangle size={14} /> }
      : { label: "HIGH RISK — SIGNALS BLOCKED", color: "#FF3366", icon: <AlertTriangle size={14} /> };

  const sources = [
    { name: "NewsAPI", active: true, articles: 142 },
    { name: "GDELT", active: true, articles: 89 },
    { name: "RSS Feeds", active: true, articles: 34 },
  ];

  return (
    <div
      style={{
        background: "linear-gradient(135deg, #0A1020, #0D1830)",
        border: "1px solid rgba(0,212,255,0.12)",
        borderRadius: 6,
        overflow: "hidden",
        fontFamily: "'Rajdhani', sans-serif",
      }}
    >
      {/* Header */}
      <div
        className="flex items-center justify-between px-5 py-3"
        style={{ borderBottom: "1px solid rgba(0,212,255,0.08)" }}
      >
        <div className="flex items-center gap-2">
          <Globe2 size={16} style={{ color: "#00D4FF" }} />
          <span style={{ color: "#E2EAF4", fontWeight: 600, fontSize: 14, letterSpacing: "0.06em" }}>
            MACRO RISK FILTER
          </span>
        </div>
        <div
          className="flex items-center gap-1.5"
          style={{
            color: status.color,
            fontSize: 11,
            fontFamily: "'JetBrains Mono', monospace",
            background: status.color + "15",
            border: `1px solid ${status.color}30`,
            padding: "3px 8px",
            borderRadius: 3,
          }}
        >
          {status.icon}
          <span>{status.label}</span>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-0">
        {/* Gauge */}
        <div className="flex flex-col items-center justify-center py-4 px-4">
          <GaugeArc score={score} />
          <div
            className="mt-2 px-3 py-1.5 text-center"
            style={{
              background: "rgba(0,0,0,0.2)",
              border: `1px solid ${status.color}25`,
              borderRadius: 4,
              width: "100%",
            }}
          >
            <div style={{ color: "#5A7A9A", fontSize: 9, fontFamily: "'JetBrains Mono', monospace", letterSpacing: "0.15em" }}>
              THRESHOLD
            </div>
            <div style={{ color: "#FFB300", fontFamily: "'JetBrains Mono', monospace", fontSize: 13, fontWeight: 600 }}>
              70 / 100
            </div>
            <div style={{ color: "#5A7A9A", fontSize: 9, fontFamily: "'JetBrains Mono', monospace" }}>
              signals blocked above
            </div>
          </div>

          {/* Sources */}
          <div className="mt-3 w-full">
            {sources.map((s) => (
              <div key={s.name} className="flex items-center justify-between py-1">
                <div className="flex items-center gap-1.5">
                  <div style={{ width: 5, height: 5, borderRadius: "50%", background: s.active ? "#00F5C4" : "#5A7A9A" }} />
                  <span style={{ color: "#7A9AB8", fontSize: 10, fontFamily: "'JetBrains Mono', monospace" }}>{s.name}</span>
                </div>
                <span style={{ color: "#5A7A9A", fontSize: 9, fontFamily: "'JetBrains Mono', monospace" }}>{s.articles} art.</span>
              </div>
            ))}
          </div>
        </div>

        {/* News feed */}
        <div
          className="flex flex-col py-3 px-3"
          style={{ borderLeft: "1px solid rgba(0,212,255,0.08)" }}
        >
          <div className="flex items-center gap-2 mb-3">
            <Newspaper size={12} style={{ color: "#5A7A9A" }} />
            <span style={{ color: "#5A7A9A", fontSize: 9, fontFamily: "'JetBrains Mono', monospace", letterSpacing: "0.15em" }}>
              LIVE HEADLINES
            </span>
          </div>
          <div className="flex flex-col gap-2 flex-1 overflow-hidden">
            {newsItems.map((n, i) => (
              <motion.div
                key={i}
                animate={{ opacity: i === activeNews ? 1 : 0.35, x: i === activeNews ? 0 : -2 }}
                transition={{ duration: 0.4 }}
                className="px-2 py-2"
                style={{
                  background: i === activeNews ? "rgba(0,212,255,0.05)" : "transparent",
                  border: `1px solid ${i === activeNews ? "rgba(0,212,255,0.12)" : "transparent"}`,
                  borderRadius: 3,
                }}
              >
                <div className="flex items-center justify-between mb-0.5">
                  <span
                    style={{
                      color: impactColors[n.impact],
                      fontSize: 8,
                      fontFamily: "'JetBrains Mono', monospace",
                      letterSpacing: "0.1em",
                      background: impactColors[n.impact] + "20",
                      padding: "1px 4px",
                      borderRadius: 2,
                    }}
                  >
                    {n.source}
                  </span>
                  <span style={{ color: "#5A7A9A", fontSize: 8, fontFamily: "'JetBrains Mono', monospace" }}>
                    {n.time}
                  </span>
                </div>
                <div
                  style={{
                    color: "#B0C4D8",
                    fontSize: 10,
                    lineHeight: 1.4,
                    fontFamily: "'Rajdhani', sans-serif",
                  }}
                >
                  {n.headline}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
