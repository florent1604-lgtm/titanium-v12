import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Cpu, Eye, Loader2, CheckCircle, TrendingUp, AlertTriangle } from "lucide-react";

interface Analysis {
  asset: string;
  model: string;
  timestamp: string;
  trend: string;
  structure: string;
  orderBlocks: string;
  fvg: string;
  recommendation: string;
  confidence: number;
  color: string;
}

const analyses: Analysis[] = [
  {
    asset: "BTC/USDT",
    model: "Qwen2.5-VL",
    timestamp: "14:32:07",
    trend: "Bullish — price trading above EMA200, clean higher-high structure",
    structure: "Break of structure confirmed on 4H. Demand zone at 66.8k holding.",
    orderBlocks: "Strong bullish OB identified at 67.1k–67.4k. Price mitigated and reversed.",
    fvg: "Fair Value Gap open at 68.0k–68.3k. Partial fill expected before continuation.",
    recommendation: "LONG bias maintained. Target 69.2k (FVG close + previous high). Invalidated below 66.9k.",
    confidence: 84,
    color: "#FFB300",
  },
  {
    asset: "ETH/USDT",
    model: "LLaVA",
    timestamp: "14:29:42",
    trend: "Bearish — price below EMA50, rejection at 3,900 resistance",
    structure: "Change of Character (CHoCH) confirmed on 1H at 3,880. Lower lows forming.",
    orderBlocks: "Bearish OB at 3,890–3,920 providing selling pressure.",
    fvg: "Imbalance below at 3,760–3,810. Likely fill before reversal.",
    recommendation: "SHORT bias. TP1: 3,820 (FVG entry). TP2: 3,740. SL above 3,960.",
    confidence: 71,
    color: "#00D4FF",
  },
];

export function AIVisionPanel() {
  const [selected, setSelected] = useState(0);
  const [scanning, setScanning] = useState(false);

  const triggerScan = () => {
    setScanning(true);
    setTimeout(() => setScanning(false), 2500);
  };

  const a = analyses[selected];

  return (
    <div
      style={{
        background: "linear-gradient(135deg, #0A1020, #0D1830)",
        border: "1px solid rgba(0,212,255,0.12)",
        borderRadius: 6,
        overflow: "hidden",
        fontFamily: "'Rajdhani', sans-serif",
      }}
    >
      {/* Header */}
      <div
        className="flex items-center justify-between px-5 py-3"
        style={{ borderBottom: "1px solid rgba(0,212,255,0.08)" }}
      >
        <div className="flex items-center gap-2">
          <Cpu size={16} style={{ color: "#00D4FF" }} />
          <span style={{ color: "#E2EAF4", fontWeight: 600, fontSize: 14, letterSpacing: "0.06em" }}>
            AI VISION ANALYSIS
          </span>
          <span
            style={{
              color: "#9B59B6",
              fontSize: 9,
              fontFamily: "'JetBrains Mono', monospace",
              background: "rgba(155,89,182,0.15)",
              border: "1px solid rgba(155,89,182,0.2)",
              padding: "2px 6px",
              borderRadius: 2,
            }}
          >
            Ollama · Local
          </span>
        </div>
        <button
          onClick={triggerScan}
          style={{
            background: scanning ? "rgba(0,212,255,0.08)" : "rgba(0,212,255,0.12)",
            border: "1px solid rgba(0,212,255,0.25)",
            color: "#00D4FF",
            fontSize: 10,
            fontFamily: "'JetBrains Mono', monospace",
            letterSpacing: "0.08em",
            padding: "4px 10px",
            borderRadius: 3,
            cursor: "pointer",
            display: "flex",
            alignItems: "center",
            gap: 5,
          }}
        >
          {scanning ? <Loader2 size={11} className="animate-spin" /> : <Eye size={11} />}
          {scanning ? "SCANNING..." : "SCAN CHART"}
        </button>
      </div>

      {/* Asset selector */}
      <div
        className="flex gap-1 px-5 py-2"
        style={{ borderBottom: "1px solid rgba(0,212,255,0.08)" }}
      >
        {analyses.map((a, i) => (
          <button
            key={a.asset}
            onClick={() => setSelected(i)}
            style={{
              background: selected === i ? `${a.color}18` : "transparent",
              border: `1px solid ${selected === i ? a.color + "40" : "rgba(0,212,255,0.08)"}`,
              color: selected === i ? a.color : "#5A7A9A",
              fontSize: 10,
              fontFamily: "'JetBrains Mono', monospace",
              letterSpacing: "0.08em",
              padding: "3px 10px",
              borderRadius: 3,
              cursor: "pointer",
            }}
          >
            {a.asset}
          </button>
        ))}
      </div>

      {/* Analysis content */}
      <AnimatePresence mode="wait">
        <motion.div
          key={selected}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -8 }}
          transition={{ duration: 0.25 }}
          className="p-5 relative"
        >
          <div className="flex items-start justify-between mb-4">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <CheckCircle size={14} style={{ color: "#00F5C4" }} />
                <span style={{ color: "#E2EAF4", fontSize: 13, fontWeight: 600, letterSpacing: "0.04em" }}>
                  {a.asset} — {a.model}
                </span>
              </div>
              <span style={{ color: "#5A7A9A", fontSize: 9, fontFamily: "'JetBrains Mono', monospace" }}>
                Last scan: {a.timestamp} UTC
              </span>
            </div>
            {/* Confidence ring */}
            <div style={{ position: "relative", width: 56, height: 56 }}>
              <svg width="56" height="56" viewBox="0 0 56 56">
                <circle cx="28" cy="28" r="22" fill="none" stroke="rgba(0,212,255,0.1)" strokeWidth="4" />
                <circle
                  cx="28"
                  cy="28"
                  r="22"
                  fill="none"
                  stroke={a.confidence > 75 ? "#00F5C4" : "#FFB300"}
                  strokeWidth="4"
                  strokeLinecap="round"
                  strokeDasharray={`${(a.confidence / 100) * 138.23} 138.23`}
                  transform="rotate(-90 28 28)"
                />
              </svg>
              <div
                style={{
                  position: "absolute",
                  inset: 0,
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <span style={{ color: "#E2EAF4", fontFamily: "'JetBrains Mono', monospace", fontSize: 13, fontWeight: 700, lineHeight: 1 }}>
                  {a.confidence}
                </span>
                <span style={{ color: "#5A7A9A", fontFamily: "'JetBrains Mono', monospace", fontSize: 7 }}>
                  conf%
                </span>
              </div>
            </div>
          </div>

          {/* Analysis grid */}
          <div className="grid grid-cols-2 gap-3">
            {[
              { label: "TREND", value: a.trend, icon: <TrendingUp size={10} />, color: "#00D4FF" },
              { label: "STRUCTURE", value: a.structure, icon: <AlertTriangle size={10} />, color: "#FFB300" },
              { label: "ORDER BLOCKS", value: a.orderBlocks, icon: <Eye size={10} />, color: "#9B59B6" },
              { label: "FAIR VALUE GAPS", value: a.fvg, icon: <Cpu size={10} />, color: "#00F5C4" },
            ].map((item) => (
              <div
                key={item.label}
                className="px-3 py-2.5"
                style={{
                  background: "rgba(0,0,0,0.2)",
                  border: "1px solid rgba(0,212,255,0.08)",
                  borderRadius: 4,
                }}
              >
                <div className="flex items-center gap-1.5 mb-1.5">
                  <span style={{ color: item.color }}>{item.icon}</span>
                  <span style={{ color: "#5A7A9A", fontSize: 8, fontFamily: "'JetBrains Mono', monospace", letterSpacing: "0.12em" }}>
                    {item.label}
                  </span>
                </div>
                <p style={{ color: "#B0C4D8", fontSize: 11, lineHeight: 1.5, fontFamily: "'Rajdhani', sans-serif" }}>
                  {item.value}
                </p>
              </div>
            ))}
          </div>

          {/* Recommendation */}
          <div
            className="mt-3 px-4 py-3"
            style={{
              background: `linear-gradient(90deg, ${a.color}0D, transparent)`,
              border: `1px solid ${a.color}25`,
              borderRadius: 4,
            }}
          >
            <div className="flex items-center gap-2 mb-1">
              <div style={{ width: 6, height: 6, borderRadius: "50%", background: a.color, boxShadow: `0 0 8px ${a.color}` }} />
              <span style={{ color: "#5A7A9A", fontSize: 9, fontFamily: "'JetBrains Mono', monospace", letterSpacing: "0.12em" }}>
                AI RECOMMENDATION
              </span>
            </div>
            <p style={{ color: "#E2EAF4", fontSize: 12, lineHeight: 1.5, fontFamily: "'Rajdhani', sans-serif" }}>
              {a.recommendation}
            </p>
          </div>

          {/* Scanning overlay */}
          <AnimatePresence>
            {scanning && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                style={{
                  position: "absolute",
                  inset: 0,
                  background: "rgba(5,10,20,0.85)",
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  justifyContent: "center",
                  gap: 12,
                }}
              >
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                >
                  <Cpu size={32} style={{ color: "#00D4FF" }} />
                </motion.div>
                <div style={{ color: "#00D4FF", fontFamily: "'JetBrains Mono', monospace", fontSize: 12, letterSpacing: "0.15em" }}>
                  PROCESSING CHART IMAGE...
                </div>
                <div
                  style={{
                    width: 200,
                    height: 3,
                    background: "rgba(0,212,255,0.1)",
                    borderRadius: 2,
                    overflow: "hidden",
                  }}
                >
                  <motion.div
                    initial={{ x: "-100%" }}
                    animate={{ x: "100%" }}
                    transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut" }}
                    style={{ width: "60%", height: "100%", background: "linear-gradient(90deg, transparent, #00D4FF, transparent)" }}
                  />
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
