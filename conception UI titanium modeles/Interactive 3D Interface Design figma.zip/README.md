
  # Interactive 3D Interface Design

  This is a code bundle for Interactive 3D Interface Design. The original project is available at https://www.figma.com/design/8uW3JdmSzuN1F2FrAt76Cg/Interactive-3D-Interface-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  